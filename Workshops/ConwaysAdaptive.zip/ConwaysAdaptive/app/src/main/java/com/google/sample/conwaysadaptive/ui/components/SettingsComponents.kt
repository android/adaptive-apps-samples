package com.google.sample.conwaysadaptive.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import com.google.sample.conwaysadaptive.ui.theme.DmMono
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val PaneBackground = Color.White
val TextBlack = Color.Black
val InactiveCyan = Color(0xFFD4F0F5)
val ComboYellow = Color(0xFFFDFCCE)
val OutlineVariant = Color(0xFFC4C7C5)
val OnSecondaryContainer = Color(0xFF4A4459)
val NeutralText = Color(0xFF444746)

@Composable
fun PlayPauseButton(
    isPlaying: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    FloatingActionButton(
        onClick = onToggle,
        containerColor = InactiveCyan,
        contentColor = TextBlack,
        shape = CircleShape,
        modifier = modifier
            .widthIn(min = 48.dp, max = 164.dp)
            .height(56.dp)
            .border(1.dp, TextBlack, CircleShape)
    ) {
        Icon(
            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (isPlaying) "Pause" else "Play"
        )
    }
}

@Composable
fun SettingsButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .border(1.dp, OutlineVariant, CircleShape)
            .background(Color.Transparent, CircleShape)
    ) {
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = "Settings",
            tint = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun SettingsTitle(
    onBack: () -> Unit,
    showBackButton: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        if (showBackButton) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .border(1.dp, OutlineVariant, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextBlack
                )
            }
        }
        Text(
            text = "Settings",
            color = TextBlack,
            fontFamily = DmMono,
            fontSize = 24.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridSizeSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "Grid size",
            color = TextBlack,
            fontFamily = DmMono,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
        
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..4f,
            steps = 3,
            colors = SliderDefaults.colors(
                thumbColor = Color.Black,
                activeTrackColor = Color.Black,
                inactiveTrackColor = InactiveCyan,
                activeTickColor = Color.White,
                inactiveTickColor = Color.White
            )
        )
    }
}

@Composable
fun InitialTemplateComboBox(
    selectedTemplate: String,
    onTemplateSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "Initial template",
            color = TextBlack,
            fontFamily = DmMono,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Button(
                onClick = { /* Handle action */ },
                shape = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp, topEnd = 4.dp, bottomEnd = 4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ComboYellow,
                    contentColor = OnSecondaryContainer
                ),
                contentPadding = PaddingValues(horizontal = 24.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(end = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = selectedTemplate, 
                    fontFamily = DmMono,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.weight(1f)
                )
            }
            
            Button(
                onClick = { /* Handle dropdown */ },
                shape = RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp, topEnd = 28.dp, bottomEnd = 28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ComboYellow,
                    contentColor = OnSecondaryContainer
                ),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier
                    .width(56.dp)
                    .fillMaxHeight()
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Options"
                )
            }
        }
    }
}

@Composable
fun SpeedSelector(
    selectedSpeed: Int,
    onSpeedSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val speeds = listOf(1, 2, 3, 5, 10)
    
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "Speed",
            color = TextBlack,
            fontFamily = DmMono,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
        
        Row(
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            speeds.forEach { speed ->
                val isSelected = speed == selectedSpeed
                val shape = if (isSelected) CircleShape else RoundedCornerShape(8.dp)
                val backgroundColor = if (isSelected) Color.Black else InactiveCyan
                val contentColor = if (isSelected) Color.White else OnSecondaryContainer
                
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .clip(shape)
                        .background(backgroundColor)
                        .clickable { onSpeedSelected(speed) }
                ) {
                    Text(
                        text = speed.toString(),
                        color = contentColor,
                        fontFamily = DmMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsActionButtons(
    onReset: () -> Unit,
    onApply: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.fillMaxWidth()
    ) {
        OutlinedButton(
            onClick = onReset,
            shape = CircleShape,
            border = BorderStroke(1.dp, OutlineVariant),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
            modifier = Modifier.weight(0.4f)
        ) {
            Text(
                text = "Reset",
                color = NeutralText,
                fontFamily = DmMono,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp
            )
        }
        
        Button(
            onClick = onApply,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black,
                contentColor = Color.White
            ),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
            modifier = Modifier.weight(0.6f)
        ) {
            Text(
                text = "Apply Changes",
                fontFamily = DmMono,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
fun SettingsPanel(
    gridSize: Float,
    onGridSizeChange: (Float) -> Unit,
    modifier: Modifier = Modifier, 
    onBack: () -> Unit = {}, 
    showBackButton: Boolean = true
) {
    var selectedSpeed by remember { mutableIntStateOf(2) }

    Column(
        verticalArrangement = Arrangement.spacedBy(48.dp),
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(PaneBackground)
            .padding(24.dp)
    ) {
        SettingsTitle(onBack = onBack, showBackButton = showBackButton)
        
        GridSizeSlider(
            value = gridSize,
            onValueChange = onGridSizeChange
        )
        
        InitialTemplateComboBox(
            selectedTemplate = "Combo",
            onTemplateSelected = { /* Handle template selection */ }
        )
        
        SpeedSelector(
            selectedSpeed = selectedSpeed,
            onSpeedSelected = { selectedSpeed = it }
        )
        
        SettingsActionButtons(
            onReset = { /* Handle reset */ },
            onApply = { /* Handle apply */ }
        )
    }
}

@Preview
@Composable
fun PlayPauseButtonPreview() {
    Surface {
        PlayPauseButton(isPlaying = false, onToggle = {})
    }
}

@Preview
@Composable
fun SettingsButtonPreview() {
    Surface {
        SettingsButton(onClick = {})
    }
}

@Preview
@Composable
fun SettingsTitlePreview() {
    Surface(modifier = Modifier.padding(16.dp)) {
        SettingsTitle(onBack = {})
    }
}

@Preview
@Composable
fun GridSizeSliderPreview() {
    Surface(modifier = Modifier.padding(16.dp)) {
        GridSizeSlider(value = 2f, onValueChange = {})
    }
}

@Preview
@Composable
fun InitialTemplateComboBoxPreview() {
    Surface(modifier = Modifier.padding(16.dp)) {
        InitialTemplateComboBox(selectedTemplate = "Combo", onTemplateSelected = {})
    }
}

@Preview
@Composable
fun SpeedSelectorPreview() {
    Surface(modifier = Modifier.padding(16.dp)) {
        SpeedSelector(selectedSpeed = 2, onSpeedSelected = {})
    }
}

@Preview
@Composable
fun SettingsActionButtonsPreview() {
    Surface(modifier = Modifier.padding(16.dp)) {
        SettingsActionButtons(onReset = {}, onApply = {})
    }
}

@Preview
@Composable
fun SettingsPanelPreview() {
    Surface(modifier = Modifier.padding(16.dp)) {
        SettingsPanel(
            gridSize = 2f,
            onGridSizeChange = {}
        )
    }
}

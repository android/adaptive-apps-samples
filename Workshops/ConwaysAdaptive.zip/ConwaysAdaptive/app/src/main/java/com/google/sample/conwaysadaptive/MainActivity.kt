package com.google.sample.conwaysadaptive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ComposeUiFlags
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.ExperimentalMediaQueryApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation3.runtime.NavEntry
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.scene.Scene
import androidx.navigation3.scene.SceneStrategy
import androidx.navigation3.scene.SceneStrategyScope
import androidx.navigation3.ui.NavDisplay
import com.google.sample.conwaysadaptive.ui.components.GameScreen
import com.google.sample.conwaysadaptive.ui.components.SettingsPanel
import com.google.sample.conwaysadaptive.ui.theme.ConwaysAdaptiveTheme
import com.google.sample.conwaysadaptive.viewmodel.ConwayViewModel
import kotlinx.serialization.Serializable

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalComposeUiApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        ComposeUiFlags.isMediaQueryIntegrationEnabled = true
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ConwaysAdaptiveTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ConwaysAdaptive(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Serializable
private object ConwayGame : NavKey

@Serializable
private object ConwaySettings : NavKey

class AdaptiveScene<T : Any>(
    override val key: Any,
    override val previousEntries: List<NavEntry<T>>,
    val entry: NavEntry<T>,
    val lWeight: Float = .6f,
    val rWeight: Float = .4f,
    val viewModel: ConwayViewModel
) : Scene<T> {
    override val entries = listOf(entry)
    override val content: @Composable () -> Unit = {
        Row(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(lWeight)
            ) {
                entry.Content()
            }
            Box(modifier = Modifier.weight(rWeight)) {
                val gridSize by viewModel.gridSize.collectAsState()
                SettingsPanel(
                    gridSize = gridSize,
                    onGridSizeChange = viewModel::updateGridSize,
                    modifier = Modifier
                        .fillMaxSize(),
                    showBackButton = false
                )
            }
        }
    }
}

class AdaptiveSceneStrategy<T : Any>(
    private val isExpanded: Boolean,
    private val isMedium: Boolean,
    private val viewModel: ConwayViewModel
) : SceneStrategy<T> {
    override fun SceneStrategyScope<T>.calculateScene(entries: List<NavEntry<T>>): Scene<T>? {
        return when {
            isExpanded -> {
                AdaptiveScene(
                    key = "ExpandedScene_${entries.last().contentKey}",
                    previousEntries = entries.dropLast(1),
                    entry = entries.last(),
                    viewModel = viewModel
                )
            }
            isMedium -> {
                AdaptiveScene(
                    key = "ExpandedScene_${entries.last().contentKey}",
                    previousEntries = entries.dropLast(1),
                    entry = entries.last(),
                    lWeight = .5f,
                    rWeight = .5f,
                    viewModel = viewModel
                )
            }
            else -> null
        }
    }
}

@OptIn(ExperimentalMediaQueryApi::class)
@Composable
fun ConwaysAdaptive(
    modifier: Modifier = Modifier,
    viewModel: ConwayViewModel = viewModel()
) {
    val backStack = rememberNavBackStack(ConwayGame)
    var isPlaying by remember { mutableStateOf(false) }

    val (isExpanded, isMedium) =  mediaQueryPlayground()

    LaunchedEffect(isExpanded) {
        if (isExpanded && backStack.last() == ConwaySettings) {
            backStack.removeLastOrNull()
        }
    }

    val adaptiveStrategy = remember(isExpanded, isMedium, viewModel) { AdaptiveSceneStrategy<NavKey>(isExpanded, isMedium, viewModel) }

    NavDisplay(
        backStack = backStack,
        onBack = { backStack.removeLastOrNull() },
        sceneStrategies = listOf(adaptiveStrategy),
        entryProvider = entryProvider {
            entry<ConwayGame> {
                val gridSize by viewModel.gridSize.collectAsState()
                GameScreen(
                    gridSize = gridSize,
                    isExpanded = isExpanded,
                    isPlaying = isPlaying,
                    onTogglePlay = { isPlaying = !isPlaying },
                    onSettingsClick = { backStack.add(ConwaySettings) }
                )
            }
            entry<ConwaySettings> {
                val gridSize by viewModel.gridSize.collectAsState()
                SettingsPanel(
                    gridSize = gridSize,
                    onGridSizeChange = viewModel::updateGridSize,
                    modifier = Modifier
                        .fillMaxSize()
                        .wrapContentSize(Alignment.Center)
                        .padding(16.dp)
                        .widthIn(max = 400.dp),
                    onBack = { backStack.removeLastOrNull() },
                    showBackButton = true
                )
            }
        },
        modifier = modifier
    )
}

@file:OptIn(ExperimentalFlexBoxApi::class, ExperimentalGridApi::class,
    ExperimentalMediaQueryApi::class
)

package com.google.sample.conwaysadaptive

import androidx.compose.foundation.layout.ExperimentalFlexBoxApi
import androidx.compose.foundation.layout.ExperimentalGridApi
import androidx.compose.foundation.layout.FlexAlignItems
import androidx.compose.foundation.layout.FlexBox
import androidx.compose.foundation.layout.FlexJustifyContent
import androidx.compose.foundation.layout.Grid
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.ExperimentalMediaQueryApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.derivedMediaQuery
import androidx.compose.ui.unit.dp

@Composable
fun GridPlayground(gridSize: Int, modifier: Modifier, cell: @Composable (Int) -> Unit) {

}


@Composable
fun FlexBoxPlayground(
    isExpanded: Boolean,
    modifier: Modifier,
    settingsButton: @Composable () -> Unit,
    playPauseButton: @Composable (Modifier) -> Unit
) {

}

@Composable
fun mediaQueryPlayground() : Pair<Boolean, Boolean> {

    return true to true
}
package com.google.sample.conwaysadaptive.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConwayViewModel : ViewModel() {
    private val _gridSize = MutableStateFlow(2f)
    val gridSize: StateFlow<Float> = _gridSize.asStateFlow()

    fun updateGridSize(size: Float) {
        _gridSize.value = size
    }
}

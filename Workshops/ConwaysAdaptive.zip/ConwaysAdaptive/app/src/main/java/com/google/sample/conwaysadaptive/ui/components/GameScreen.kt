package com.google.sample.conwaysadaptive.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalFlexBoxApi
import androidx.compose.foundation.layout.ExperimentalGridApi
import androidx.compose.foundation.layout.FlexAlignItems
import androidx.compose.foundation.layout.FlexBox
import androidx.compose.foundation.layout.FlexJustifyContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.google.sample.conwaysadaptive.FlexBoxPlayground
import com.google.sample.conwaysadaptive.GridPlayground

@OptIn(ExperimentalGridApi::class, ExperimentalFlexBoxApi::class)
@Composable
fun GameScreen(
    gridSize: Float,
    isExpanded: Boolean,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {

    Column(modifier = modifier.fillMaxSize()) {

        GridPlayground(
            gridSize = gridSize.toInt(),
            modifier = Modifier
                .padding(24.dp)
                .weight(1f)
                .fillMaxWidth()
        ) { _ ->

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Transparent)
                    .border(0.5.dp, OutlineVariant)
            )
        }

        FlexBoxPlayground(
            isExpanded = isExpanded,
            modifier = Modifier
                .padding(start = 24.dp, end = 24.dp, bottom = 24.dp)
                .fillMaxWidth(),
            settingsButton = { SettingsButton(onClick = onSettingsClick) }) { modifier ->

            PlayPauseButton(
                isPlaying = isPlaying, onToggle = onTogglePlay, modifier = modifier
            )
        }
    }
}

@Preview(device = Devices.PIXEL_9)
@Preview(device = Devices.PIXEL_FOLD)
@Composable
fun GameScreenPreview() {
    Surface {
        GameScreen(
            gridSize = 0.5f,
            isExpanded = false,
            isPlaying = false,
            onTogglePlay = {},
            onSettingsClick = {})
    }
}
